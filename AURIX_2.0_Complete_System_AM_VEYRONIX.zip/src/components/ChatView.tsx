import React, { useEffect, useRef, useState } from "react";
import { Plus, Send, Volume2 } from "lucide-react";
import type {
  AppSettings,
  AurixLanguage,
  ChatMessage,
  ConversationSummary,
  ThinkingDepth,
  WebsiteRecord,
} from "../types/aurix";

interface ChatViewProps {
  conversations: ConversationSummary[];
  websites: WebsiteRecord[];
  settings: AppSettings;
  pendingQuickPrompt: string | null;
  onClearPendingQuickPrompt: () => void;
  onConversationsUpdated: (convs: ConversationSummary[]) => void;
}

export function ChatView({
  conversations,
  websites,
  settings,
  pendingQuickPrompt,
  onClearPendingQuickPrompt,
  onConversationsUpdated,
}: ChatViewProps) {
  const [activeConvId, setActiveConvId] = useState<string | undefined>(conversations[0]?.id);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [scopedWebsite, setScopedWebsite] = useState("All");
  const [language, setLanguage] = useState<AurixLanguage>(settings.language);
  const [thinkingLevel, setThinkingLevel] = useState<ThinkingDepth>(settings.thinkingLevel);
  const [loading, setLoading] = useState(false);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!activeConvId) {
      setMessages([]);
      return;
    }
    fetch(`/api/conversations/${activeConvId}/messages`)
      .then((r) => r.json())
      .then((data) => {
        if (Array.isArray(data)) setMessages(data);
      })
      .catch(() => {});
  }, [activeConvId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const sendMessage = async (textToSend: string) => {
    const trimmed = textToSend.trim();
    if (!trimmed || loading) return;
    setError(null);
    setLoading(true);

    const optimisticUser: ChatMessage = {
      id: `temp_${Date.now()}`,
      conversationId: activeConvId || "new",
      role: "user",
      content: trimmed,
      createdAt: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, optimisticUser]);
    setInput("");

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          conversationId: activeConvId,
          message: trimmed,
          model: settings.activeModel,
          language,
          thinkingLevel,
          scopedWebsite,
          mode: "chat",
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to reach AURIX core.");
      }
      setActiveConvId(data.conversationId);
      setMessages((prev) => [
        ...prev.filter((m) => m.id !== optimisticUser.id),
        data.userMessage,
        data.assistantMessage,
      ]);
      if (Array.isArray(data.conversations)) {
        onConversationsUpdated(data.conversations);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Conversation error.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (pendingQuickPrompt) {
      const prompt = pendingQuickPrompt;
      onClearPendingQuickPrompt();
      setActiveConvId(undefined);
      setMessages([]);
      sendMessage(prompt);
    }
  }, [pendingQuickPrompt]);

  const speakReply = async (msg: ChatMessage) => {
    try {
      setSpeakingId(msg.id);
      const res = await fetch("/api/voice/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: msg.content,
          voiceName: settings.voiceName,
          language,
          speed: settings.voiceSpeed,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Voice synthesis failed.");
      const audio = new Audio(`data:${data.mimeType || "audio/wav"};base64,${data.audioBase64}`);
      audio.onended = () => setSpeakingId(null);
      audio.onerror = () => setSpeakingId(null);
      await audio.play();
    } catch (err) {
      setSpeakingId(null);
      setError(err instanceof Error ? err.message : "Could not play AURIX voice.");
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[calc(100vh-140px)] min-h-[560px]">
      {/* Conversation History Column */}
      <aside className="lg:col-span-3 bg-white dark:bg-[#0D1420] border border-slate-200 dark:border-slate-800/80 rounded-xl p-4 flex flex-col">
        <button
          type="button"
          onClick={() => {
            setActiveConvId(undefined);
            setMessages([]);
            setError(null);
          }}
          className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>New Session</span>
        </button>

        <div className="mt-4 text-xs font-medium text-slate-500 dark:text-slate-400 px-1">
          Recent Sessions
        </div>
        <div className="mt-2 flex-1 overflow-y-auto space-y-1">
          {conversations.length === 0 ? (
            <p className="text-xs text-slate-500 px-2 py-4">No saved sessions yet.</p>
          ) : (
            conversations.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setActiveConvId(c.id)}
                className={`w-full text-left px-3 py-2.5 rounded-lg text-xs transition-colors cursor-pointer ${
                  activeConvId === c.id
                    ? "bg-cyan-500/10 text-cyan-600 dark:text-cyan-300 font-medium"
                    : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60"
                }`}
              >
                <div className="truncate">{c.title}</div>
                <div className="mt-0.5 text-[11px] text-slate-400 font-mono tabular-nums">
                  {c.language} · {c.updatedAt.slice(0, 10)}
                </div>
              </button>
            ))
          )}
        </div>
      </aside>

      {/* Active Chat Workspace */}
      <section className="lg:col-span-9 bg-white dark:bg-[#0D1420] border border-slate-200 dark:border-slate-800/80 rounded-xl flex flex-col overflow-hidden">
        {/* Controls Toolbar */}
        <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800/80 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-3">
            <label className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2">
              <span>Project Scope:</span>
              <select
                value={scopedWebsite}
                onChange={(e) => setScopedWebsite(e.target.value)}
                className="bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-slate-700 rounded-md px-2.5 py-1.5 text-xs text-slate-900 dark:text-slate-100"
              >
                <option value="All">All Isolated Records</option>
                {websites.map((w) => (
                  <option key={w.id} value={w.name}>
                    {w.name}
                  </option>
                ))}
              </select>
            </label>

            <label className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2">
              <span>Language:</span>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value as AurixLanguage)}
                className="bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-slate-700 rounded-md px-2.5 py-1.5 text-xs text-slate-900 dark:text-slate-100"
              >
                <option value="English">English</option>
                <option value="Urdu">Urdu</option>
                <option value="Hindi">Hindi</option>
              </select>
            </label>

            <label className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2">
              <span>Reasoning:</span>
              <select
                value={thinkingLevel}
                onChange={(e) => setThinkingLevel(e.target.value as ThinkingDepth)}
                className="bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-slate-700 rounded-md px-2.5 py-1.5 text-xs text-slate-900 dark:text-slate-100 font-mono"
              >
                <option value="LOW">LOW</option>
                <option value="MEDIUM">MEDIUM</option>
                <option value="HIGH">HIGH</option>
                <option value="XHIGH">XHIGH</option>
              </select>
            </label>
          </div>

          <span className="text-xs font-mono text-slate-500 dark:text-slate-400">
            {settings.activeModel}
          </span>
        </div>

        {/* Message Feed */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center max-w-lg mx-auto">
              <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100">
                AURIX Intelligence Ready
              </h3>
              <p className="mt-2 text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
                Ask about architecture, code debugging, AM VEYRONIX strategy, website planning, mathematics, or documents in English, Urdu, or Hindi.
              </p>
            </div>
          ) : (
            messages.map((m) => (
              <div
                key={m.id}
                className={`flex flex-col ${m.role === "user" ? "items-end" : "items-start"}`}
              >
                <div className="flex items-center gap-2 mb-1 text-[11px] text-slate-400">
                  <span>{m.role === "user" ? "Abdul Muheeb" : "AURIX"}</span>
                  {m.modelUsed && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono">{m.modelUsed}</span>
                    </>
                  )}
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">{m.createdAt.slice(11, 19)}</span>
                </div>
                <div
                  className={`max-w-3xl rounded-xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap ${
                    m.role === "user"
                      ? "bg-cyan-600 text-white"
                      : "bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100"
                  }`}
                >
                  {m.content}
                </div>
                {m.role === "assistant" && (
                  <button
                    type="button"
                    onClick={() => speakReply(m)}
                    disabled={speakingId === m.id}
                    className="mt-1.5 inline-flex items-center gap-1.5 text-xs text-slate-500 hover:text-cyan-500 transition-colors cursor-pointer"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>{speakingId === m.id ? "Speaking..." : `Speak (${settings.voiceName})`}</span>
                  </button>
                )}
              </div>
            ))
          )}
          {loading && (
            <div className="text-xs text-cyan-600 dark:text-cyan-400 font-mono">
              AURIX is reasoning ({thinkingLevel})...
            </div>
          )}
          {error && (
            <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-600 dark:text-red-400">
              {error}
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Input Composer */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            sendMessage(input);
          }}
          className="p-4 border-t border-slate-200 dark:border-slate-800/80 flex gap-3"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={`Message AURIX in ${language}...`}
            className="flex-1 bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-slate-700 rounded-lg px-4 py-2.5 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-cyan-500"
          />
          <button
            type="submit"
            disabled={loading || !input.trim()}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white text-sm font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <Send className="w-4 h-4" />
            <span>Send</span>
          </button>
        </form>
      </section>
    </div>
  );
}
